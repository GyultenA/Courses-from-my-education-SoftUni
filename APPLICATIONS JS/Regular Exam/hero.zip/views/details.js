import { render, html, nothing } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"

import { getAuthData } from "../src/autMid.js";
import { handleLike } from "../src/productService.js";

const root = document.querySelector("main");

const detailsTemplate= (hero, authData, likeCount, isLiked) => html`
<section id="details">
<div id="details-wrapper">
  <img id="details-img" src=${hero.imageUrl} alt="example1" />
  <div>
  <p id="details-category">${hero.category}</p>
  <div id="info-wrapper">
    <div id="details-description">
      <p id="description">${hero.description}</p>
         <p id ="more-info">${hero.moreInfo}</p>
    </div>
  </div>
    <h3>Is This Useful:<span id="likes">${likeCount}</span></h3>
${hero._ownerId === getAuthData()._id ? html`
    <div id="action-buttons">
    <a href=${`/edit/${hero._id}`} id="edit-btn">Edit</a>
    <a href="javascript:void(0)" id="delete-btn" @click=${(e) => onDelete(e, hero._id)}>Delete</a>
    </div>` : nothing}
 ${authData && authData._id !== hero._ownerId && !isLiked ? html`
 <div id="action-buttons">
    <a href="" id="like-btn" @click=${(e) => likeClick(e, hero._id)}>Like</a></div>` : nothing}
</div>
</section>`


function likeClick(e, characterId) {
    handleLike(e, characterId)
        .then(() => {
            const likeBtn = document.getElementById("like-btn");
            const likeEl = document.getElementById("likes");
            likeBtn.style.display = "none";
            likeEl.textContent = Number(likeEl.textContent) + 1;
        })

}


function onDelete(e, id) {
    e.preventDefault();
    if (confirm("Are you sure?")) {
        // Save it!
        page.redirect("/delete/" + id);
    }
}


export function detailsView(ctx) {
    render(detailsTemplate(ctx.hero, ctx.authData, ctx.likeCount, ctx.isLikedByUser), root)
}