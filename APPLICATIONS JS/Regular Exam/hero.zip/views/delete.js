import page from "../node_modules/page/page.mjs";

import { deleteHero } from "../src/productService.js";

export function deleteView(ctx) {
  deleteHero(ctx.params.id)
    .then(() => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}