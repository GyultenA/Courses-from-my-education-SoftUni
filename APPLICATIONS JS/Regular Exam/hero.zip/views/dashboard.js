import { render, html } from "../node_modules/lit-html/lit-html.js";

const root = document.querySelector("main");


const characterTemplate = (hero) => html`<div class="character">
<img src=${hero.imageUrl} alt="example1" />
<div class="hero-info">
  <h3 class="category">${hero.category}</h3>
  <p class="description">${hero.description}</p>
  <a class="details-btn" href="/details/${hero._id}">More Info</a>
</div>`

const sectionChar = (characters) => html`
<section id="characters">
  ${characters.map((hero) => characterTemplate(hero))}
</section>`


const dashboardTemplate = (characters) => html`
<h2>Characters</h2>
${characters && characters.length > 0 ? sectionChar(characters) : html`<h2>No added Heroes yet.</h2>`}`




export function dashboardView(ctx, next) {
  render(dashboardTemplate(ctx.characters), root);
}