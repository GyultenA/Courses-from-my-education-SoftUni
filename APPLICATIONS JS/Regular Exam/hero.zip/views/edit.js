import { html, render} from "../node_modules/lit-html/lit-html.js"
import page from "../node_modules/page/page.mjs"

import { submitEdit } from "../src/productService.js";

const root = document.querySelector("main");

const editTemplate=(hero) => html`
<section id="edit">
<div class="form">
  <img class="border" src="./images/border.png" alt="">
  <h2>Edit Character</h2>
  <form @submit=${(e) => submitEdit(e, hero._id)} class="edit-form">
    <input
    type="text"
    name="category"
    id="category"
    value=${hero.category}
    placeholder="Character Type"
  />
  <input
    type="text"
    name="image-url"
    id="image-url"
    value=${hero.imageUrl}
    placeholder="Image URL"
  />
  <textarea
  id="description"
  name="description"
  placeholder="Description"
  rows="2"
  cols="10"
>${hero.description}</textarea>
<textarea
  id="additional-info"
  name="additional-info"
  placeholder="Additional Info"
  rows="2"
  cols="10"
>${hero.moreInfo}</textarea>
    <button type="submit">Edit</button>
  </form>
  <img class="border" src="./images/border.png" alt="">
</div>
</section>`


export function editAlbumView(ctx){
    render(editTemplate(ctx.hero), root)
}