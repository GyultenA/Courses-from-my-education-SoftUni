import { getAuthData } from "./autMid.js";

export function authMiddleware(ctx, next) {
    ctx.authData = getAuthData();
    next();
  }