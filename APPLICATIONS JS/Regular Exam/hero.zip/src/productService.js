import page from "../node_modules/page/page.mjs";

import { charactersUrl} from "./api.js";
import { getAuthData } from "./autMid.js";

export function getAllCharacter(ctx, next) {
  fetch(charactersUrl)
    .then((res) => res.json())
    .then((data) => {
      ctx.characters = data;
      console.log(ctx.characters)
      next();
    });
}

export function getHeroById(ctx, next) {
  fetch(`http://localhost:3030/data/characters/${ctx.params.id}`)
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.hero = data;
      console.log(ctx.hero)
      next();
    });
}

export function getLikeCount(ctx, next) {
  let id = ctx.params.id
  fetch(`http://localhost:3030/data/useful?where=characterId%3D%22${id}%22&distinct=_ownerId&count`)
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.likeCount = data;
      console.log(ctx.likeCount)
      next();
    });
}

export function isLikedByUser(ctx, next) {
  let id = ctx.params.id
  fetch(
    `http://localhost:3030/data/useful?where=characterId%3D%22${ctx.hero._id}%22%20and%20_ownerId%3D%22${ctx.authData._id}%22&count`
  )
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.isLikedByUser = data !== 0;
      console.log(ctx.isLikedByUser)
      next();
    });
}

export function submitCreate(e) {
  e.preventDefault();

  const formData = new FormData(e.target);
  const category = formData.get("category");
  const imageUrl = formData.get("image-url");
  const description = formData.get("description");
  const moreInfo = formData.get("additional-info");


  if (!category || !imageUrl || !description || !moreInfo) {
    return window.alert("All fields are required!");
  }

  const body = { category, imageUrl, description, moreInfo };

  createHero(body)
    .then((res) => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

export function submitEdit(e, id) {
  e.preventDefault();
  const formData = new FormData(e.target);

  const category = formData.get("category");
  const imageUrl = formData.get("image-url");
  const description = formData.get("description");
  const moreInfo = formData.get("additional-info");

  if (!category || !imageUrl || !description || !moreInfo) {
    return window.alert("All fields are required!");
  }

  const body = { category, imageUrl, description, moreInfo };

  edit(body, id)
    .then((res) => {
      page.redirect(`/details/${id}`);
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

function createHero(body) {
  return fetch(`http://localhost:3030/data/characters`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function edit(body, id) {
  return fetch(`http://localhost:3030/data/characters/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function like(body) {
  return fetch(`http://localhost:3030/data/useful`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

export function handleLike(e, characterId) {
  e.preventDefault();

  const body = {
    characterId,
  };

  return like(body, characterId)
    .then((res) => {

    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

// DELETE

export function deleteHero(id) {
  return fetch(`http://localhost:3030/data/characters/${id}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
  });
}