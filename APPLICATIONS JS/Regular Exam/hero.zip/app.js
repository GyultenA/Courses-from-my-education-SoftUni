import page from "./node_modules/page/page.mjs";

import { authMiddleware } from "./src/authdata.js";

import { navbarView } from "./views/navbar.js";
import {homeView} from "./views/home.js"
import {loginView} from "./views/login.js";
import {registerView} from "./views/register.js"
import { logoutView } from "./views/logout.js"
import { dashboardView } from "./views/dashboard.js";
import { detailsView } from "./views/details.js";
import { createView } from "./views/create.js";
import { editAlbumView } from "./views/edit.js";
import { getAllCharacter } from "./src/productService.js";
import { getHeroById } from "./src/productService.js";

import {getLikeCount, isLikedByUser } from "./src/productService.js";

import { deleteView } from "./views/delete.js";


page(authMiddleware);
page(navbarView);
page("/", homeView);
page("/login", loginView);
page("/register", registerView);
page("/logout", logoutView);
page("/details/:id", getHeroById, getLikeCount, isLikedByUser, detailsView);
page("/dashboard", getAllCharacter, dashboardView); 
page("/create", getAllCharacter, createView);
page("/edit/:id", getHeroById, editAlbumView);
page("/delete/:id", deleteView);

page.start();