function attachEvents() {
    //console.log('TODO...');
    const textArea = document.getElementById("messages")
    const url = "http://localhost:3030/jsonstore/messenger"
    document.getElementById("refresh").addEventListener("click", onLoadCommenst)
    document.getElementById('submit').addEventListener("click", onSubmit)


    async function onLoadCommenst(e) {
        textArea.textContent = "";
        const response = await fetch(url)
        const data = await response.json();
        //console.log(data)
        // Object.values(data)
        //console.log(data);

        Object.values(data).forEach(row => {
            textArea.textContent += `${row.author}: ${row.content}\n`
        })
        textArea.textContent = textArea.textContent.trim()
          // textArea.textContent = Object.value(data).join("\n") - syshtoto
    }

    async function onSubmit(e) {
        //const [author, post] =  document.querySelectorAll("#controls input[type='text']")
        // author.value  post.value

        const dataPost = document.querySelectorAll("#controls input[type='text']")
        const author = dataPost[0].value;
        const content = dataPost[1].value;
        const data = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                author,
                content
            })
        }
       await fetch(url, data);
        dataPost[0].value = "";
        dataPost[1].value = "";

    }



}

attachEvents();