

export function deleteView(){
    
}