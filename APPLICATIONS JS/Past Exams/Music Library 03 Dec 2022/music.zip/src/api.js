
const baseUrl = "http://localhost:3030";
export const loginUrl = baseUrl + "/users/login";
export const registerUrl = baseUrl + "/users/register";
export const logoutUrl = baseUrl + "/users/logout";
export const productsUrl = baseUrl + "/data/albums?sortBy=_createdOn%20desc";