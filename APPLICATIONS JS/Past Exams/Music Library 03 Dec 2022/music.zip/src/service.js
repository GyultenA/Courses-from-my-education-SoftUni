

//export function getAuthData(){
  //  return JSON.parse(sessionStorage.getItem("userData"))
//}

export function loginhandler(e){
    e.preventDefault();
    const formdata = new FormData (e.target)

    const email = formdata.get("email");
    const password = formdata.get("password");

    if(!email || !password){
        alert("All fields are required")
    }

    const body= {
        email, password
    }
}

export function registerHandler(e){
  e.preventDefault();
  const formdata = new FormData (e.target)
    const email = formdata.get("email");
    const password = formdata.get("password");
    const rePass = formdata.get("re-password");

    if(!email || !password){
        
    }
}




function login(body){
  return fetch(loginUrl, {
    method:""
  })
}

