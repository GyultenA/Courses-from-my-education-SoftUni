import page from "../node_modules/page/page.mjs";

import { productsUrl } from "./api.js";
import { getAuthData } from "./autMid.js";

export function getAlbums(ctx, next) {
  fetch(productsUrl)
    .then((res) => res.json())
    .then((data) => {
      ctx.albums = data;
      console.log(ctx.albums)
      next();
    });
}

export function getAlbumById(ctx, next) {
  fetch(`http://localhost:3030/data/albums/${ctx.params.id}`)
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.album = data;
      console.log(ctx.album)
      next();
    });
}

export function getLikeCount(ctx, next) {
  let id = ctx.params.id
  fetch(
    `http://localhost:3030/data/likes?where=albumId%3D%22${id}%22&distinct=_ownerId&count`
  )
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.likeCount = data;
      console.log(ctx.likeCount)
      next();
    });
}

export function isLikedByUser(ctx, next) {
  let id = ctx.params.id
  fetch(
    `http://localhost:3030/data/likes?where=albumId%3D%22${ctx.album._id}%22%20and%20_ownerId%3D%22${ctx.authData._id}%22&count`
  )
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.isLikedByUser = data !== 0;
      console.log(ctx.isLikedByUser)
      next();
    });
}

export function submitCreate(e) {
  e.preventDefault();

  const formData = new FormData(e.target);
  const singer = formData.get("singer");
  const album = formData.get("album");
  const imageUrl = formData.get("imageUrl");
  const release = formData.get("release");
  const label = formData.get("label");
  const sales = formData.get("sales");

  if (!singer || !album || !imageUrl || !release || !label || !sales) {
    return window.alert("All fields are required!");
  }

  const body = {
    singer, album, imageUrl, release, label, sales
  };

  createAlbum(body)
    .then((res) => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

export function submitEdit(e, id) {
  e.preventDefault();

 
  const formData = new FormData(e.target);
  const singer = formData.get("singer");
  const album = formData.get("album");
  const imageUrl = formData.get("imageUrl");
  const release = formData.get("release");
  const label = formData.get("label");
  const sales = formData.get("sales");

  if (!singer || !album || !imageUrl || !release || !label || !sales) {
    return window.alert("All fields are required!");
  }

  const body = {
    singer, album, imageUrl, release, label, sales
  };

  edit(body, id)
    .then((res) => {
      page.redirect(`/details/${id}`);
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

function createAlbum(body) {
  return fetch(productsUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function edit(body, id) {
  return fetch(`http://localhost:3030/data/albums/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function like(body) {
  return fetch(`http://localhost:3030/data/likes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

export function handleLike(e, albumId) {
  e.preventDefault();

  const body = {
    albumId,
  };

  return like(body, albumId)
    .then((res) => {
      // page.redirect("/products/" + productId);
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

// DELETE

export function deleteAlbum(id) {
  return fetch(`http://localhost:3030/data/albums/${id}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
  });
}