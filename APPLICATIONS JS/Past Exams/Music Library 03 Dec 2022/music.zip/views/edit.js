import { html, render} from "../node_modules/lit-html/lit-html.js"
import page from "../node_modules/page/page.mjs"

import { submitEdit } from "../src/productService.js";

const root = document.querySelector("main");

const editTemplate=(album) => html`
<section id="edit">
<div class="form">
  <h2>Edit Album</h2>
  <form @submit=${(e) => submitEdit(e, album._id)} class="edit-form">
    <input type="text" name="singer" id="album-singer" value=${album.singer} placeholder="Singer/Band" />
    <input type="text" name="album" id="album-album" value=${album.album} placeholder="Album" />
    <input type="text" name="imageUrl" id="album-img" value=${album.imageUrl} placeholder="Image url" />
    <input type="text" name="release" id="album-release" value=${album.release} placeholder="Release date" />
    <input type="text" name="label" id="album-label" value=${album.label} placeholder="Label" />
    <input type="text" name="sales" id="album-sales" value=${album.sales} placeholder="Sales" />
    <button type="submit">post</button>
  </form>
</div>
</section>`


export function editAlbumView(ctx){

    render(editTemplate(ctx.album), root)
}