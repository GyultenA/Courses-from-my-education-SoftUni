import page from "../node_modules/page/page.mjs";

import { deleteAlbum } from "../src/productService.js";

export function deleteView(ctx) {
  deleteAlbum(ctx.params.id)
    .then(() => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}