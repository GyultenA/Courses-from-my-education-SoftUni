import { render, html, nothing } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"

import { getAuthData } from "../src/autMid.js";
import { handleLike } from "../src/productService.js";

const root = document.querySelector("main");

const detailsTemplate = (album, authData, likeCount, isLiked) => html`
<section id="details">
<div id="details-wrapper">
  <p id="details-title">Album Details</p>
  <div id="img-wrapper">
    <img src=${album.imageUrl} alt="example1" />
  </div>
  <div id="info-wrapper">
    <p><strong>Band:</strong><span id="details-singer">${album.singer}</span></p>
    <p>
      <strong>Album name:</strong><span id="details-album">${album.album}</span>
    </p>
    <p><strong>Release date:</strong><span id="details-release">${album.release}</span></p>
    <p><strong>Label:</strong><span id="details-label">${album.label}</span></p>
    <p><strong>Sales:</strong><span id="details-sales">${album.sales}</span></p>
  </div>
  <div id="likes">Likes: <span id="likes-count">${likeCount}</span></div>
  ${album._ownerId === getAuthData()._id ? html`
                    <div id="action-buttons">
                      <a href=${`/edit/${album._id}`} id="edit-btn">Edit</a>
                      <a href="" id="delete-btn" @click=${(e) => onDelete(e, album._id)}>Delete</a>
                    </div>`
        : nothing}
  ${authData && authData._id !== album._ownerId && !isLiked ? html`<div id="action-buttons">
    <a href="" id="like-btn" @click=${(e) => likeClick(e, album._id)}>Like</a></div>` : nothing}
</div>
</section>`


function likeClick(e, albumId) {
    handleLike(e, albumId)
        .then(() => {
            const likeBtn = document.getElementById("like-btn");
            const likeEl = document.getElementById("likes-count");
            likeBtn.style.display = "none";
            likeEl.textContent = Number(likeEl.textContent) + 1;
        })

}


function onDelete(e, id) {
    e.preventDefault();
    if (confirm("Are you sure?")) {
        // Save it!
        page.redirect("/delete/" + id);
    }
}


export function detailsView(ctx) {

    render(detailsTemplate(ctx.album, ctx.authData, ctx.likeCount, ctx.isLikedByUser), root)
}