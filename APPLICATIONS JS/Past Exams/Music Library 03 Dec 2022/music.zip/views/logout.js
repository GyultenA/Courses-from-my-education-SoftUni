import page from "../node_modules/page/page.mjs";

import { logout } from "../src/autMid.js";

export function logoutView() {
    logout()
        .then(() => {
            page.redirect("/");
        })
        .catch((err) => {
            page.redirect("/");
        });
}