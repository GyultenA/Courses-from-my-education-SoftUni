import page from "./node_modules/page/page.mjs";
import { render } from "./node_modules/lit-html/lit-html.js";

//import { showRegisterView } from "./registerView.js";
//import { showLoginView } from "./loginView.js";
import { userService } from "./src/userService.js";
import { userHelper } from "./src/userHelper.js";

import { showHome } from "./views/home.js";
import { showDashboard } from "./views/dashboard.js";
import { showLogin } from "./views/login.js";
import { showRegister } from "./views/register.js";
import { showDetailsView } from "./views/details.js";
import { editView } from "./views/edit.js";
import { createFacts } from "./views/add.js";
//import { showHomeView} from "./homeView.js"
//import { browseTeam } from "./browse.js";


//console.log("work")
const root = document.querySelector("main");

const userA = document.querySelector(".user");
const guestA = document.querySelector(".guest");

page(decorationContext)
page("/", showHome)
page("/dashboard", showDashboard)
page("/login", showLogin)
page("/register", showRegister)
page("/logout", logout)
page('/details/:id', showDetailsView)
page("/edit/:id", editView)
page("/add", createFacts)

page.start();
updateNav()


async function logout() {
    await userService.logout()
    updateNav()
    goTo("/")
}



function decorationContext(ctx, next) {
    ctx.render = renderer;
    ctx.updateNav = updateNav;
    ctx.goTo = goTo;

    next()
}

function renderer(template) {
    render(template, root)
}

function updateNav() {
    const userData = userHelper.getUserData()

    if (userData) {
        userA.style.display = "block";
        guestA.style.display = "none";
    } else {
        userA.style.display = "none";
        guestA.style.display = "block";
    }
}

function goTo(path) {
    page.redirect(path)
}

