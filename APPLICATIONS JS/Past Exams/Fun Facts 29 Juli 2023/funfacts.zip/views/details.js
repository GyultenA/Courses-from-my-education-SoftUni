import { dataService} from "../src/dataService.js";
import { html } from "../node_modules/lit-html/lit-html.js"
import { userHelper } from "../src/userHelper.js";


const detailsTemplate = (item, isOwner, totalLikesCount) => html`
<section id="details">
<div id="details-wrapper">
  <img id="details-img" src=${item.imageUrl} alt="example1" />
  <p id="details-category">${item.category}</p>
  <div id="info-wrapper">
    <div id="details-description">
      <p id="description">${item.description}</p>
         <p id ="more-info">${item.moreInfo}</p>
    </div>
    ${isOwner ?
        html`<div id="action-buttons">
  <a href="/edit/${item._id}" id="edit-btn">Edit</a>
  <a @click=${deleteItem} href="javascript:void(0)" id="delete-btn">Delete</a></div>` : html`<a @click=${onLikes} href="" id="like-btn">Like</a>`}

    <h3>Likes:<span id="likes">${totalLikesCount}</span></h3>
  </div>
</div>
</section>`


let context = null;
let userId;
let totalLikesCount;
let didUserLikeded;

export async function showDetailsView(ctx) {
    //console.log("work")
    context = ctx;
    const id = context.params.id;
    const data = await dataService.getFactById(id);
    const isOwner = userHelper.getUserId() === data._ownerId

    context.render(detailsTemplate(data, isOwner, totalLikesCount))
}

async function deleteItem(e) {
    e.preventDefault()
    const id = context.params.id
    await dataService.deleteFact(id)
    context.goTo("/dashboard")
}

async function onLikes(e) {
  e.preventDefault();

  const factId = context.params.id;
  const fact = await dataService.getFactById(factId);
  const user = context.user;

  const likes = { factId: factId};
  await dataService.likesCount(likes)

  if (user != null) {
    userId = user._id;
    didUserLikeded = await dataService.didUserLiked(factId, userId);
  }

  totalLikesCount = await dataService.getTotalLikes(factId);
 
}




