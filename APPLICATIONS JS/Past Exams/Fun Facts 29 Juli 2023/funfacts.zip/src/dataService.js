import { api } from "./api.js"


const dataendPoint = {
    allFunFacts: "data/facts?sortBy=_createdOn%20desc",
    getSingleFact: "data/facts/",
    getLikes: "data/likes"

}

async function getAllFacts() {
    return await api.get(dataendPoint.allFunFacts)
}


async function getFactById(id) {
    return await api.get(dataendPoint.getSingleFact + id)
}

async function createFact(data) {
    return await api.post(dataendPoint.getSingleFact, data)
}

async function updateFact(id, data) {
    return await api.put(dataendPoint.getSingleFact + id, data)
}

async function deleteFact(id) {
    return await api.del(dataendPoint.getSingleFact + id)
}

async function likesCount(id) {
    return await api.post(dataendPoint.getLikes, id)
}


const host = "http://localhost:3030/"


async function getTotalLikes(factId) {
    return await api.get(host + `/data/likes?where=factId%3D%22${factId}%22&distinct=_ownerId&count`);
}

async function didUserLiked(factId, userId) {
    return await api.get(host + `/data/likes?where=factId%3D%22${factId}%22%20and%20_ownerId%3D%22${userId}%22&count`);
}

export const dataService = {
    getAllFacts,
    getFactById,
    createFact,
    updateFact,
    deleteFact,
    likesCount,
    getTotalLikes,
    didUserLiked
}