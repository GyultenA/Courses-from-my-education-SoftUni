import { html} from "../node_modules/lit-html/lit-html.js"
import { dataService } from "../src/dataService.js";
import { userHelper } from "../src/userHelper.js";

const detailsTemplaet =(item, isOwner, isLoggin,eventCount, totalCount) => html`
<section id="details">
<div id="details-wrapper">
  <img id="details-img" src=${item.imageUrl}alt="example1" />
  <p id="details-title">${item.name}</p>
  <p id="details-category">
    Category: <span id="categories">${item.category}</span>
  </p>
  <p id="details-date">
    Date:<span id="date">${item.date}</span></p>
  <div id="info-wrapper">
    <div id="details-description">
      <span>${item.description}</span>
    </div>
    <h3>Going: <span id="go">${totalCount}</span> times.</h3>
  </div>
  <div id="action-buttons">
 ${isOwner ? html` 
    <a href="/edit/${item._id}" id="edit-btn">Edit</a>
    <a href="javascript:void(0)" @click=${deleteEvent} id="delete-btn">Delete</a>` : ""}
${(()=> {
    if(eventCount ===0){
        if(isLoggin && !isOwner){
            return html`<a href="javascript:void(0)"  @click=${onClickGo} id="go-btn">Going</a>`
        }
    }
} 
)}
  </div>
</div>
</section>`



let context = null;

let userId;
let totalCount;
let eventCount;




export async function showDetailsView(ctx){
    context=ctx;
    const id = context.params.id;
    const data = await dataService.getEventById(id);
    const isOwner = await userHelper.getUserId() === data._ownerId

    const user = context.user;
    if(user !== null){
        userId= user._id;
        eventCount = await dataService.guestsForEvent(id, userId)
    }
    const isLoggin = user !== undefined

    totalCount= await dataService.getTotalGuests(id)

    context.render(detailsTemplaet(data, isOwner, isLoggin, eventCount,totalCount))
}

async function deleteEvent(e){
    e.preventDefault();
    const id = context.params.id;

    if (confirm("Are you sure?")) {
        await dataService.deleteEvent(id);
        context.goTo("/dashboard")
      } 
}
async function onClickGo(e){
    e.preventDefault();
    const eventId = context.params.id

    await dataService.addPeopleToEvent(eventId)
}

//async function onDelete() {
   // const confirmed = confirm("Are you sure?");
    //if (confirmed) {
     // await deleteEventById(eventId);
     // ctx.page.redirect("/dashboard");
   // }
 // }

