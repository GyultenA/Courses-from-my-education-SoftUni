import { api } from "./api.js"


const dataendPoint = {
    allEvents: "data/events?sortBy=_createdOn%20desc",
    getSingleEvent: "data/events",
    getEventId: "data/events/" ,
    addPeople: "data/going"

}

async function getAllEvents() {
    return await api.get(dataendPoint.allEvents)
}


async function getEventById(id) {
   return await api.get(dataendPoint.getEventId + id)
}

async function createEvent(data) {
  return await api.post(dataendPoint.getSingleEvent, data)
}

async function updateEvent(id, data) {
  return await api.put(dataendPoint.getEventId + id, data)
}

async function deleteEvent(id) {
    return await api.del(dataendPoint.getEventId + id)
}

async function addPeopleToEvent(eventId) {
   return await api.post(dataendPoint.addPeople, eventId)
}


const host = "http://localhost:3030/"


async function getTotalGuests(eventId) {
  return await get(host + `data/going?where=eventId%3D%22${eventId}%22&distinct=_ownerId&count`);
}

async function guestsForEvent (eventId, userId) {
   return await get(host + `data/going?where=eventId%3D%22${eventId}%22%20and%20_ownerId%3D%22${userId}%22&count`);
}

export const dataService = {
    getAllEvents,
    createEvent,
    getEventById,
    deleteEvent,
    updateEvent,
    addPeopleToEvent,
    getTotalGuests,
    guestsForEvent

}