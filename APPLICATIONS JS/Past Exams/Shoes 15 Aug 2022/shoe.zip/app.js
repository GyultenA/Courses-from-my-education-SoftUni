import page from "./node_modules/page/page.mjs";

import { authMiddleware } from "./services/authdata.js";

import { navbarView } from "./views/navbar.js";
import {showHomeView} from "./views/home.js"
import { showRegisterView } from "./views/register.js";
import { logoutView } from "./views/logout.js"
import { dashboardView } from "./views/dashboard.js";
import { showLoginView } from "./views/login.js";
import { showCreateView } from "./views/create.js";
import { showEdit } from "./views/edit.js";
import { showDetailsView } from "./views/details.js";
import { showSearch } from "./views/search.js";

import { getProductById } from "./services/productService.js";
import { getProducts } from "./services/productService.js";



page(authMiddleware);
page(navbarView);
page("/", showHomeView);
page("/login", showLoginView);
page("/register", showRegisterView);
page("/logout", logoutView);
page(
  "/details/:id",
  getProductById,
  showDetailsView
);
page("/dashboard", getProducts, dashboardView);
page("/create", getProducts, showCreateView);
page("/edit/:id", getProductById, showEdit);
page("/search", showSearch)

page.start();