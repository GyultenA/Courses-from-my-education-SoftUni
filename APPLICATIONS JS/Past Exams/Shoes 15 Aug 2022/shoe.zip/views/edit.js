import { html, render } from "../node_modules/lit-html/lit-html.js"
import { handleEditProduct } from "../services/productService.js";


const root = document.querySelector("main");


const editTemplate = (item) => html`<section id="edit">
<div class="form">
  <h2>Edit item</h2>
  <form @submit=${(e) => handleEditProduct(e, item._id)} class="edit-form">
    <input
      type="text"
      name="brand"
      value=${item.brand}
      id="shoe-brand"
      placeholder="Brand"
    />
    <input
      type="text"
      name="model"
      id="shoe-model"
      value=${item.model}
      placeholder="Model"
    />
    <input
      type="text"
      name="imageUrl"
      id="shoe-img"
      value=${item.imageUrl}
      placeholder="Image url"
    />
    <input
      type="text"
      name="release"
      id="shoe-release"
      value=${item.release}
      placeholder="Release date"
    />
    <input
      type="text"
      name="designer"
      id="shoe-designer"
      value=${item.designer}
      placeholder="Designer"
    />
    <input
      type="text"
      name="value"
      id="shoe-value"
      value=${item.value}
      placeholder="Value"
    />

    <button type="submit">post</button>
  </form>
</div>
</section>`



export function showEdit(ctx) {
    render(editTemplate(ctx.product), root)
}

