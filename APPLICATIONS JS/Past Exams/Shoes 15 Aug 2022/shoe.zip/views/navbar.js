import page from "../node_modules/page/page.mjs"
import { render, html } from "../node_modules/lit-html/lit-html.js"

const root = document.querySelector("header");

const navbarTemplate = (isLogin) => html`<a id="logo" href="/"
><img id="logo-img" src="./images/logo.png" alt=""
/></a>
<nav>
<div>
  <a href="/dashboard">Dashboard</a>
</div>
${isLogin ? userTemplate() : guestTemplate()}
</nav>`


const userTemplate = () => html`
<div class="user">
<a href="/search">Search</a>
<a href="/create">Add Pair</a>
<a href="/logout">Logout</a>
</div>`

const guestTemplate = () => html`
<div class="guest">
<a href="/login">Login</a>
<a href="/register">Register</a>
</div>`

export function navbarView(ctx, next) {
    console.log(ctx)
    const isLogin = ctx.authData;
    render(navbarTemplate(isLogin), root);
    next()
}