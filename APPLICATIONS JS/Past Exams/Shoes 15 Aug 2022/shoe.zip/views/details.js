import { html, render } from "../node_modules/lit-html/lit-html.js"
import page from "../node_modules/page/page.mjs"

import { getAuthData } from "../services/autMid.js"
import { deleteProduct } from "../services/productService.js"

const root = document.querySelector("main");

const detailsTemplate = (item, isOwner) => html`
<section id="details">
<div id="details-wrapper">
  <p id="details-title">Shoe Details</p>
  <div id="img-wrapper">
    <img src=${item.imageUrl} alt="example1" />
  </div>
  <div id="info-wrapper">
    <p>Brand: <span id="details-brand">${item.brand}</span></p>
    <p>
      Model: <span id="details-model">${item.model}</span>
    </p>
    <p>Release date: <span id="details-release">${item.release}</span></p>
    <p>Designer: <span id="details-designer">${item.designer}</span></p>
    <p>Value: ${item.value} <span id="details-value"></span>$</p>
  </div>
    ${isOwner ? html`<div id="action-buttons">
    <a href="/edit/${item._id}" id="edit-btn">Edit</a>
    <a href="javascript:void(0)" @click=${(e)=> deleteItem(e, item._id)} id="delete-btn">Delete</a>
  </div>` : ""}
</div>
</section>`





export function showDetailsView(ctx) {
  
  ctx.product
  console.log(ctx.product)
  ctx.authData
    const isOwner = ctx.product._ownerId === getAuthData()._id

    render(detailsTemplate(ctx.product, isOwner), root);
}

function deleteItem(e, id){
    e.preventDefault();
   
    if (confirm("Are you sure?")) {
      deleteProduct(id)
      .then(() => {
        page.redirect("/dashboard");
      })
      .catch((err) => {
       window.alert(err.message);
        console.log(err);
      });
        
      }
    
}
