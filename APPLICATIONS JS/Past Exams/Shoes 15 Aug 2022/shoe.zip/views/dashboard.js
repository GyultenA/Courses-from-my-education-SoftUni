import { html, render } from "../node_modules/lit-html/lit-html.js"

const root = document.querySelector("main");

const dashboardTemplate =(data) => html`
<h2>Collectibles</h2>
${data && data.length > 0 ? shoeSection(data) : html`<h2>There are no items added yet.</h2>`}`

const shoeSection = (data) => html`
<section id="dashboard">
    <ul class="card-wrapper">
 ${data.map((shoes) => cadrTemplate(shoes))}
    </ul>
    </section>`


const cadrTemplate =(shoes) => html`
<li class="card">
<img src=${shoes.imageUrl} alt="travis" />
<p>
  <strong>Brand: </strong><span class="brand">${shoes.brand}</span>
</p>
<p>
  <strong>Model: </strong
  ><span class="model">${shoes.model}</span>
</p>
<p><strong>Value:</strong><span class="value">${shoes.value}</span>$</p>
<a class="details-btn" href="/details/${shoes._id}">Details</a>
</li>`


export function dashboardView(ctx) {
  render(dashboardTemplate(ctx.products), root);
}