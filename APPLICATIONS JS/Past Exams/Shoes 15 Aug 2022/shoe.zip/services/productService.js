import page from "../node_modules/page/page.mjs";

import { createUrl, productsUrl } from "./api.js";
import { getAuthData } from "./autMid.js";



//export function searchText(query, ctx, next) {
 /// fetch(`http://localhost:3030/data/fruits?where=name%20LIKE%20%22${query}%22`)
 // .then((res) => res.json())
  //  .then((data) => {
   //   ctx.text = data;
    //  console.log(ctx.text)
    //  next();
    //});
//}

export function getProducts(ctx, next) {
  fetch(productsUrl)
    .then((res) => res.json())
    .then((data) => {
      ctx.products = data;
      next();
    });
}

export function getProductById(ctx, next) {
  fetch(`http://localhost:3030/data/shoes/${ctx.params.id}`)
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      ctx.product = data;
      next();
    });
}



export function handleCreateProduct(e) {
  e.preventDefault();

  const formData = new FormData(e.target);
  const brand = formData.get("brand");
  const model = formData.get("model");
  const imageUrl = formData.get("imageUrl");
  const release = formData.get("release");
  const designer = formData.get("designer");
  const value = formData.get("value");

  if (!brand || !model || !imageUrl || !release || !designer || !value) {
    return window.alert("All fields are required!")
  }

  const body = {
    brand, model, imageUrl, release, designer, value
  };

  createProduct(body)
    .then((res) => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

export function handleEditProduct(e, id) {
  e.preventDefault();

  const formData = new FormData(e.target);
  const brand = formData.get("brand");
    const model = formData.get("model");
    const imageUrl = formData.get("imageUrl");
    const release = formData.get("release");
    const designer = formData.get("designer");
    const value = formData.get("value");

    if (!brand || !model || !imageUrl || !release || !designer || !value) {
        window.alert("All fields are required!")
    }

    const body = { brand, model, imageUrl, release, designer, value }

  editProduct(body, id)
    .then((res) => {
      page.redirect("/dashboard");
    })
    .catch((err) => {
      window.alert(err.message);
      console.log(err);
    });
}

function createProduct(body) {
  return fetch(createUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function editProduct(body, id) {
  return fetch(`http://localhost:3030/data/shoes/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

function buy(body) {
  return fetch(`http://localhost:3030/data/bought`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
    body: JSON.stringify(body),
  });
}

export function handleBuy(e, productId) {
  e.preventDefault();

  const body = {
    productId,
  };

  return buy(body, productId)
    .then((res) => {
      // page.redirect("/products/" + productId);
    })
    .catch((err) => {
      alert(err.message);
      console.log(err);
    });
}

// DELETE

export function deleteProduct(id) {
  return fetch(`http://localhost:3030/data/shoes/${id}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "X-Authorization": `${getAuthData().accessToken}`,
    },
  });
}

