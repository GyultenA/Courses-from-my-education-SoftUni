import { html } from "../node_modules/lit-html/lit-html.js"
import { dataService } from "../src/dataService.js";

const editTemplate = (item) => html`
<section id="edit">
<h2>Edit Motorcycle</h2>
<div class="form">
  <h2>Edit Motorcycle</h2>
  <form @submit=${submitEdit} class="edit-form">
    <input
      type="text"
      name="model"
      id="model"
      value=${item.model}
      placeholder="Model"
    />
    <input
      type="text"
      name="imageUrl"
      id="moto-image"
      value=${item.imageUrl}
      placeholder="Moto Image"
    />
    <input
    type="number"
    name="year"
    id="year"
    value=${item.year}
    placeholder="Year"
  />
  <input
  type="number"
  name="mileage"
  id="mileage"
  value=${item.mileage}
  placeholder="mileage"
/>
<input
  type="number"
  name="contact"
  id="contact"
  value=${item.contact}
  placeholder="contact"
/>
  <textarea
    id="about"
    name="about"
    placeholder="about"
    rows="10"
    cols="50"
  >${item.about}</textarea>
    <button type="submit">Edit Motorcycle</button>
  </form>
</div>
</section>`

let context = null;

export async function editView(ctx) {
  //console.log("work")
  context=ctx;
  const id = context.params.id;

 const data = await dataService.getMotoById(id);
 context.render(editTemplate(data))
}


async function submitEdit(e) {
  e.preventDefault();

  const formdata = new FormData(e.target)
  const model = formdata.get("model");
  const img = formdata.get("imageUrl")
  const year = formdata.get("year");
  const mileage = formdata.get("mileage");
  const contact = formdata.get("contact");
  const moreInfo = formdata.get("about");

  if (!model || !img || !year || !mileage || !contact || !moreInfo) {
    return window.alert("All fields are required!")
  }
  const id = context.params.id;

  await dataService.updateMoto(id, { model, img, year, mileage, contact, moreInfo });
  context.goTo(`/details/${id}`)

}