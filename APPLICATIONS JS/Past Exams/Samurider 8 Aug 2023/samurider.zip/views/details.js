import {html} from "../node_modules/lit-html/lit-html.js"
import { dataService } from "../src/dataService.js";
import { userHelper } from "../src/userHelper.js";

const detailsTemplate = (item, isOwner) => html`
<section id="details">
<div id="details-wrapper">
  <img id="details-img" src=${item.imageUrl} alt="example1" />
  <p id="details-title">${item.model}</p>
  <div id="info-wrapper">
    <div id="details-description">
      <p class="year">Year: ${item.year}</p>
      <p class="mileage">Mileage: ${item.mileage} km.</p>
      <p class="contact">Contact Number: ${item.contact}</p>
         <p id = "motorcycle-description">${item.about}</p>
    </div>
    </div>
    ${isOwner ? html`<div id="action-buttons">
  <a href="/edit/${item._id}" id="edit-btn">Edit</a>
  <a @click=${deleteMoto} href="javascript:void(0)" id="delete-btn">Delete</a>
</div>` : ""}
</div>
</section>`

//<!--Edit and Delete are only for creator-->
let context = null;

export async function showDetailsView(ctx){
  //console.log("work")
  context=ctx;
  const id = context.params.id;
  const data = await dataService.getMotoById(id);
  const isOwner = userHelper.getUserId() === data._ownerId

  context.render(detailsTemplate(data, isOwner))
}



async function deleteMoto(e){
  e.preventDefault();
  const id = context.params.id;
  await dataService.deleteMoto(id);
  context.goTo("/dashboard")
}