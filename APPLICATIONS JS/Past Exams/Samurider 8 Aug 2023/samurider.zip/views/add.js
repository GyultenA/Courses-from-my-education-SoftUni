import { html } from "../node_modules/lit-html/lit-html.js"
import { dataService } from "../src/dataService.js";

const createTemplate = () => html`
<section id="create">
<h2>Add Motorcycle</h2>
<div class="form">
  <h2>Add Motorcycle</h2>
  <form @submit=${submitAdd} class="create-form">
    <input
      type="text"
      name="model"
      id="model"
      placeholder="Model"
    />
    <input
      type="text"
      name="imageUrl"
      id="moto-image"
      placeholder="Moto Image"
    />
    <input
    type="number"
    name="year"
    id="year"
    placeholder="Year"
  />
  <input
  type="number"
  name="mileage"
  id="mileage"
  placeholder="mileage"
/>
<input
  type="text"
  name="contact"
  id="contact"
  placeholder="contact"
/>
  <textarea
    id="about"
    name="about"
    placeholder="about"
    rows="10"
    cols="50"
  ></textarea>
    <button type="submit">Add Motorcycle</button>
  </form>
</div>
</section>`

let context = null;

export function createMoto(ctx) {
  //console.log("work")
  context = ctx
  ctx.render(createTemplate())
}

async function submitAdd(e) {
  e.preventDefault();

  const formdata = new FormData(e.target);
  const { model, imageUrl, year, mileage, contact, about } = Object.fromEntries(formdata);

  if (!model || !imageUrl || !year || !mileage || !contact || !about) {
    return window.alert("Error")
  }

  await dataService.createMoto({ model, imageUrl, year, mileage, contact, about })
  context.goTo("/dashboard")
}