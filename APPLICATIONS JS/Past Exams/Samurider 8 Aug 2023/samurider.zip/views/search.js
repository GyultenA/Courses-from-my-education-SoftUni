import { html } from "../node_modules/lit-html/lit-html.js"
import { dataService } from "../src/dataService.js";


const searchTemplate = (data, isResult) => html`
<section id="search">
<div class="form">
  <h4>Search</h4>
  <form @submit=${searchSubmit} class="search-form">
    <input
      type="text"
      name="search"
      id="search-input"
    />
    <button class="button-list">Search</button>
  </form>
</div>
${isResult ? resultTemplate(data) : ""}
</section>`

const resultTemplate = (items) => html`
<h4 id="result-heading">Results:</h4>
<div class="search-result">
    ${items.length === 0 ? html`<h2 class="no-avaliable">No result.</h2>` : items.map(item => cardTemplate(item))}
</div>`


const cardTemplate = (item) => html`
<div class="motorcycle">
<img src=${item.imageUrl} alt="example1" />
<h3 class="model">${item.model}</h3>
  <a class="details-btn" href="/details/${item._id}">More Info</a>
</div>`

//<!--If there are matches display a div with information about every motorcycle-->



let context = null;

export function showSearchView(ctx) {
    //console.log("work")
    context = ctx;
    searchQueryText()
}

function searchSubmit(e) {
    e.preventDefault();
    const formdata = new FormData(e.target)
    const { search } = Object.fromEntries(formdata)

    if (!search) {
        return window.alert("Empty field")
    }
    searchQueryText(search)
}


async function searchQueryText(query) {
    if (query) {
        const data = await dataService.search(query);
        return context.render(searchTemplate(data, true))
    }

     context.render(searchTemplate())
}