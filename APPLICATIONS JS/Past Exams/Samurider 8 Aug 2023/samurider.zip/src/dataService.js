import { api } from "./api.js"


const dataendPoint = {
    allMotos: "data/motorcycles?sortBy=_createdOn%20desc",
   getSingleMoto: "data/motorcycles/",
   getAdd: "data/motorcycles"
}
 async function getAllMoto() {
    return await api.get (dataendPoint.allMotos)
}


 async function getMotoById(id) {
  return await api.get(dataendPoint.getSingleMoto + id)
}

async function createMoto(data) {
  return await api.post(dataendPoint.getAdd, data)
}

 async function updateMoto(id, data) {
   return await api.put(dataendPoint.getSingleMoto + id, data)
}

 async function deleteMoto(id) {
  return await api.del(dataendPoint.getSingleMoto + id)
}

async function search(query){
    return api.get(`data/motorcycles?where=model%20LIKE%20%22${query}%22`)
}


export const dataService = {
    search,
    getAllMoto,
    getMotoById,
    deleteMoto,
    updateMoto,
    createMoto
}